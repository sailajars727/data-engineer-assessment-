import argparse
import json
import os
import re
import time
from typing import Any, Dict, List, Optional

import mysql.connector
from mysql.connector import MySQLConnection


def parse_bool(value: Optional[str]) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        return 1 if value else 0
    s = str(value).strip().lower()
    if s in {"yes", "y", "true", "1"}:
        return 1
    if s in {"no", "n", "false", "0"}:
        return 0
    if s in {"", "null", "none"}:
        return None
    return None


def parse_int(value: Any) -> Optional[int]:
    if value is None or value == "":
        return None
    if isinstance(value, (int,)):
        return int(value)
    if isinstance(value, float):
        return int(round(value))
    s = str(value)
    # remove common non-digits like commas and unit labels (e.g., "5649 sqft")
    s = re.sub(r"[^0-9-]", "", s)
    if s == "" or s == "-":
        return None
    try:
        return int(s)
    except ValueError:
        return None


def parse_float(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        try:
            # remove non-numeric except dot and minus
            s = re.sub(r"[^0-9.-]", "", str(value))
            return float(s) if s not in {"", "-", "."} else None
        except Exception:
            return None


def connect_mysql(host: str, port: int, user: str, password: str, database: str) -> MySQLConnection:
    return mysql.connector.connect(
        host=host,
        port=port,
        user=user,
        password=password,
        database=database,
        autocommit=False,
    )


def ensure_schema(conn: MySQLConnection, schema_sql_path: str) -> None:
    with open(schema_sql_path, "r", encoding="utf-8") as f:
        sql_text = f.read()
    cursor = conn.cursor()
    for statement in filter(None, (s.strip() for s in sql_text.split(";"))):
        if not statement:
            continue
        cursor.execute(statement)
    cursor.close()
    conn.commit()


def get_or_create_property(conn: MySQLConnection, row: Dict[str, Any]) -> int:
    cursor = conn.cursor()
    sql = (
        "INSERT INTO properties (property_title, address, reviewed_status, most_recent_status, "
        "source, market, occupancy, flood, street_address, city, state, zip, property_type, highway, train, "
        "tax_rate, sqft_basement, htw, pool, commercial, water, sewage, year_built, sqft_mu, sqft_total, "
        "parking, bed, bath, basement_yes_no, layout, net_yield, irr, rent_restricted, neighborhood_rating, "
        "latitude, longitude, subdivision, taxes, selling_reason, seller_retained_broker, final_reviewer, school_average) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, "
        "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
        "ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)"
    )
    params = (
        row.get("Property_Title"),
        row.get("Address"),
        row.get("Reviewed_Status"),
        row.get("Most_Recent_Status"),
        row.get("Source"),
        row.get("Market"),
        None if row.get("Occupancy") is None else str(row.get("Occupancy")),
        row.get("Flood"),
        row.get("Street_Address"),
        row.get("City"),
        row.get("State"),
        row.get("Zip"),
        row.get("Property_Type"),
        row.get("Highway"),
        row.get("Train"),
        parse_float(row.get("Tax_Rate")),
        parse_int(row.get("SQFT_Basement")),
        parse_bool(row.get("HTW")),
        parse_bool(row.get("Pool")),
        parse_bool(row.get("Commercial")),
        row.get("Water"),
        row.get("Sewage"),
        parse_int(row.get("Year_Built")),
        parse_int(row.get("SQFT_MU")),
        parse_int(row.get("SQFT_Total")),
        row.get("Parking"),
        parse_int(row.get("Bed")),
        parse_int(row.get("Bath")),
        parse_bool(row.get("BasementYesNo")),
        row.get("Layout"),
        parse_float(row.get("Net_Yield")),
        parse_float(row.get("IRR")),
        parse_bool(row.get("Rent_Restricted")),
        parse_int(row.get("Neighborhood_Rating")),
        parse_float(row.get("Latitude")),
        parse_float(row.get("Longitude")),
        row.get("Subdivision"),
        parse_int(row.get("Taxes")),
        row.get("Selling_Reason"),
        row.get("Seller_Retained_Broker"),
        row.get("Final_Reviewer"),
        parse_float(row.get("School_Average")),
    )
    cursor.execute(sql, params)
    property_id = cursor.lastrowid
    cursor.close()
    return property_id


def insert_valuations(conn: MySQLConnection, property_id: int, valuations: List[Dict[str, Any]]) -> None:
    if not valuations:
        return
    cursor = conn.cursor()
    sql = (
        "INSERT INTO valuations (property_id, list_price, previous_rent, arv, expected_rent, rent_zestimate, "
        "low_fmr, high_fmr, zestimate, redfin_value) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    )
    data = []
    for v in valuations:
        data.append(
            (
                property_id,
                parse_int(v.get("List_Price")),
                parse_int(v.get("Previous_Rent")),
                parse_int(v.get("ARV")),
                parse_int(v.get("Expected_Rent")),
                parse_int(v.get("Rent_Zestimate")),
                parse_int(v.get("Low_FMR")),
                parse_int(v.get("High_FMR")),
                parse_int(v.get("Zestimate")),
                parse_int(v.get("Redfin_Value")),
            )
        )
    cursor.executemany(sql, data)
    cursor.close()


def insert_hoas(conn: MySQLConnection, property_id: int, hoas: List[Dict[str, Any]]) -> None:
    if not hoas:
        return
    cursor = conn.cursor()
    sql = "INSERT INTO hoas (property_id, hoa_amount, hoa_flag) VALUES (%s, %s, %s)"
    data = []
    for h in hoas:
        data.append((property_id, parse_int(h.get("HOA")), parse_bool(h.get("HOA_Flag"))))
    cursor.executemany(sql, data)
    cursor.close()


def insert_rehabs(conn: MySQLConnection, property_id: int, rehabs: List[Dict[str, Any]]) -> None:
    if not rehabs:
        return
    cursor = conn.cursor()
    sql = (
        "INSERT INTO rehabs (property_id, underwriting_rehab, rehab_calculation, paint_flag, flooring_flag, "
        "foundation_flag, roof_flag, hvac_flag, kitchen_flag, bathroom_flag, appliances_flag, windows_flag, "
        "landscaping_flag, trashout_flag) VALUES (" 
        "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    )
    data = []
    for r in rehabs:
        data.append(
            (
                property_id,
                parse_int(r.get("Underwriting_Rehab")),
                parse_int(r.get("Rehab_Calculation")),
                parse_bool(r.get("Paint")),
                parse_bool(r.get("Flooring_Flag")),
                parse_bool(r.get("Foundation_Flag")),
                parse_bool(r.get("Roof_Flag")),
                parse_bool(r.get("HVAC_Flag")),
                parse_bool(r.get("Kitchen_Flag")),
                parse_bool(r.get("Bathroom_Flag")),
                parse_bool(r.get("Appliances_Flag")),
                parse_bool(r.get("Windows_Flag")),
                parse_bool(r.get("Landscaping_Flag")),
                parse_bool(r.get("Trashout_Flag")),
            )
        )
    cursor.executemany(sql, data)
    cursor.close()


def process(json_path: str, conn: MySQLConnection, init_schema: bool, schema_sql_path: Optional[str]) -> None:
    if init_schema:
        if not schema_sql_path:
            raise ValueError("schema_sql_path must be provided when --init-schema is set")
        ensure_schema(conn, schema_sql_path)

    with open(json_path, "r", encoding="utf-8") as f:
        records = json.load(f)

    cursor = conn.cursor()
    try:
        for rec in records:
            property_id = get_or_create_property(conn, rec)
            insert_valuations(conn, property_id, rec.get("Valuation") or [])
            insert_hoas(conn, property_id, rec.get("HOA") or [])
            insert_rehabs(conn, property_id, rec.get("Rehab") or [])
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Normalize property JSON into MySQL tables")
    parser.add_argument("--json", default=os.path.join("data", "fake_property_data_new.json"), help="Path to input JSON")
    parser.add_argument("--host", default=os.environ.get("DB_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("DB_PORT", 3306)))
    parser.add_argument("--user", default=os.environ.get("DB_USER", "db_user"))
    parser.add_argument("--password", default=os.environ.get("DB_PASSWORD", "6equj5_db_user"))
    parser.add_argument("--database", default=os.environ.get("DB_NAME", "home_db"))
    parser.add_argument("--init-schema", action="store_true", help="Execute sql/schema.sql before loading")
    parser.add_argument("--schema-sql", default=os.path.join("sql", "schema.sql"), help="Path to DDL SQL file")
    parser.add_argument("--watch", action="store_true", help="Continuously run ETL at a fixed interval")
    parser.add_argument("--interval", type=int, default=300, help="Interval seconds when --watch is enabled (default: 300)")
    args = parser.parse_args()

    if not args.watch:
        conn = connect_mysql(args.host, args.port, args.user, args.password, args.database)
        try:
            process(args.json, conn, args.init_schema, args.schema_sql)
        finally:
            conn.close()
        return

    # Continuous run mode
    while True:
        conn = connect_mysql(args.host, args.port, args.user, args.password, args.database)
        try:
            process(args.json, conn, args.init_schema, args.schema_sql)
        except KeyboardInterrupt:
            conn.close()
            break
        except Exception:
            # Allow loop to continue on transient failures
            conn.close()
            time.sleep(max(5, min(args.interval, 60)))
        else:
            conn.close()
            time.sleep(args.interval)


if __name__ == "__main__":
    main()


