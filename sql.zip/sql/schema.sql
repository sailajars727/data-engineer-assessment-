-- Normalized schema for property data
-- Target DB: home_db (from docker-compose.initial.yml)

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- Ensure database exists (idempotent when executed by an admin)
CREATE DATABASE IF NOT EXISTS home_db CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE home_db;

-- Drop tables in reverse FK order for idempotence
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS rehabs;
DROP TABLE IF EXISTS hoas;
DROP TABLE IF EXISTS valuations;
DROP TABLE IF EXISTS properties;
SET FOREIGN_KEY_CHECKS = 1;

-- Core entity: properties
CREATE TABLE properties (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  property_title     VARCHAR(255) NULL,
  address            VARCHAR(255) NULL,
  reviewed_status    VARCHAR(64) NULL,
  most_recent_status VARCHAR(64) NULL,
  source             VARCHAR(64) NULL,
  market             VARCHAR(64) NULL,
  occupancy          VARCHAR(32) NULL,
  flood              VARCHAR(64) NULL,
  street_address     VARCHAR(255) NULL,
  city               VARCHAR(128) NULL,
  state              VARCHAR(16) NULL,
  zip                VARCHAR(16) NULL,
  property_type      VARCHAR(64) NULL,
  highway            VARCHAR(32) NULL,
  train              VARCHAR(32) NULL,
  tax_rate           DECIMAL(6,3) NULL,
  sqft_basement      INT NULL,
  htw                TINYINT(1) NULL,
  pool               TINYINT(1) NULL,
  commercial         TINYINT(1) NULL,
  water              VARCHAR(32) NULL,
  sewage             VARCHAR(32) NULL,
  year_built         SMALLINT NULL,
  sqft_mu            INT NULL,
  sqft_total         INT NULL,
  parking            VARCHAR(64) NULL,
  bed                SMALLINT NULL,
  bath               SMALLINT NULL,
  basement_yes_no    TINYINT(1) NULL,
  layout             VARCHAR(64) NULL,
  net_yield          DECIMAL(6,2) NULL,
  irr                DECIMAL(6,2) NULL,
  rent_restricted    TINYINT(1) NULL,
  neighborhood_rating TINYINT NULL,
  latitude           DECIMAL(10,6) NULL,
  longitude          DECIMAL(10,6) NULL,
  subdivision        VARCHAR(128) NULL,
  taxes              INT NULL,
  selling_reason     VARCHAR(128) NULL,
  seller_retained_broker VARCHAR(128) NULL,
  final_reviewer     VARCHAR(128) NULL,
  school_average     DECIMAL(6,2) NULL,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_property_location (street_address, city, state, zip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Child: valuations (1-to-many)
CREATE TABLE valuations (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  property_id     BIGINT UNSIGNED NOT NULL,
  list_price      INT NULL,
  previous_rent   INT NULL,
  arv             INT NULL,
  expected_rent   INT NULL,
  rent_zestimate  INT NULL,
  low_fmr         INT NULL,
  high_fmr        INT NULL,
  zestimate       INT NULL,
  redfin_value    INT NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY fk_valuations_property (property_id),
  CONSTRAINT fk_valuations_property FOREIGN KEY (property_id)
    REFERENCES properties(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Child: hoas (1-to-many)
CREATE TABLE hoas (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  property_id     BIGINT UNSIGNED NOT NULL,
  hoa_amount      INT NULL,
  hoa_flag        TINYINT(1) NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY fk_hoas_property (property_id),
  CONSTRAINT fk_hoas_property FOREIGN KEY (property_id)
    REFERENCES properties(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Child: rehabs (1-to-many)
CREATE TABLE rehabs (
  id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  property_id             BIGINT UNSIGNED NOT NULL,
  underwriting_rehab      INT NULL,
  rehab_calculation       INT NULL,
  paint_flag              TINYINT(1) NULL,
  flooring_flag           TINYINT(1) NULL,
  foundation_flag         TINYINT(1) NULL,
  roof_flag               TINYINT(1) NULL,
  hvac_flag               TINYINT(1) NULL,
  kitchen_flag            TINYINT(1) NULL,
  bathroom_flag           TINYINT(1) NULL,
  appliances_flag         TINYINT(1) NULL,
  windows_flag            TINYINT(1) NULL,
  landscaping_flag        TINYINT(1) NULL,
  trashout_flag           TINYINT(1) NULL,
  created_at              TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY fk_rehabs_property (property_id),
  CONSTRAINT fk_rehabs_property FOREIGN KEY (property_id)
    REFERENCES properties(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


